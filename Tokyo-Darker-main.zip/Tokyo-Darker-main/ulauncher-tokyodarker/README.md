# Materia Ulauncher

A theme for Ulauncher. Fork of [One Dark theme](https://github.com/sudosubin/one-dark-ulauncher).

Based on [Materia Dark](https://github.com/nana-4/materia-theme) GTK theme.

## Screenshot
![](https://raw.githubusercontent.com/levonhart/materia-dark-ulauncher/assets/screenshot.png)

## Installation

```sh
mkdir -p ~/.config/ulauncher/user-themes
git clone https://github.com/levonhart/materia-dark-ulauncher \
  ~/.config/ulauncher/user-themes/materia-dark-ulauncher
```
