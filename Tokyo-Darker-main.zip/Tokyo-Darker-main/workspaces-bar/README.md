# workspaces-bar
GNOME Shell extension that shows workspaces buttons in top panel

https://extensions.gnome.org/extension/3851/workspaces-bar/
